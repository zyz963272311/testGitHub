package com.liiwin.test;

/**
 * <p>标题： TODO</p>
 * <p>功能： </p>
 * <p>所属模块： TODO</p>
 * <p>版权： Copyright © 2017 zyzhu</p>
 * <p>公司: xyz.zyzhu</p>
 * <p>创建日期：2017年8月28日 下午10:23:31</p>
 * <p>类全名：com.liiwin.test.Test_84</p>
 * 作者：赵玉柱
 * 初审：
 * 复审：
 * 监听使用界面:
 * @version 8.0
 */
public class Test_84
{
	public static void main(String[] args)
	{
		System.out.println(Integer.parseInt("0b00000000".substring(2), 2));
		System.out.println(Integer.parseInt("0b00000001".substring(2), 2));
		System.out.println(Integer.parseInt("0b00000010".substring(2), 2));
		System.out.println(Integer.parseInt("0b00000011".substring(2), 2));
	}
}
