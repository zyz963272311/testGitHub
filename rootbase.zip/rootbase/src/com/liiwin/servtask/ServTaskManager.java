package com.liiwin.servtask;

import com.liiwin.timertask.AppTaskManager;
/**
 * <p>标题： 服务任务管理任务类</p>
 * <p>功能： </p>
 * <p>所属模块： rootbase</p>
 * <p>版权： Copyright © 2017 zyzhu</p>
 * <p>公司: xyz.zyzhu</p>
 * <p>创建日期：2017年9月7日 上午10:00:30</p>
 * <p>类全名：com.liiwin.servtask.ServTaskManager</p>
 * 作者：赵玉柱
 * 初审：
 * 复审：
 * 监听使用界面:
 * @version 8.0
 */
public class ServTaskManager extends AppTaskManager
{
}
