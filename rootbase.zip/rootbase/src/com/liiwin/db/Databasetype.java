package com.liiwin.db;

/**
 * <p>标题： 数据库类型</p>
 * <p>功能： </p>
 * <p>所属模块： TODO</p>
 * <p>版权： Copyright © 2017 SNSOFT</p>
 * <p>公司: 北京南北天地科技股份有限公司</p>
 * <p>创建日期：2017年5月27日 下午3:25:05</p>
 * <p>类全名：com.liiwin.db.Databasetype</p>
 * 作者：赵玉柱
 * 初审：
 * 复审：
 * 监听使用界面:
 * @version 8.0
 */
public class Databasetype
{
	public final static int	MYSQL		= 1;
	public final static int	ORACLE		= 2;
	public final static int	SQLSQRVER	= 4;
}
