package com.liiwin.wechat;

/**
 * <p>标题： 微信工具类</p>
 * <p>功能： </p>
 * <p>所属模块： rootbas</p>
 * <p>版权： Copyright © 2017 zyzhu</p>
 * <p>公司: xyz.zyzhu</p>
 * <p>创建日期：2017年10月11日 上午10:42:13</p>
 * <p>类全名：com.liiwin.wechat.WeChatUtil</p>
 * 作者：赵玉柱
 * 初审：
 * 复审：
 * 监听使用界面:
 * @version 8.0
 */
public class WeChatUtil
{
	/**
	 * 微信支付
	 * 
	 * 赵玉柱
	 */
	public static String weChatPay(WeChatPayParams payParams)
	{
		//get_brand_wcpay_request:ok	支付成功
		//get_brand_wcpay_request:cancel	用户取消
		//get_brand_wcpay_request:fail	支付失败
		return null;
	}
}
