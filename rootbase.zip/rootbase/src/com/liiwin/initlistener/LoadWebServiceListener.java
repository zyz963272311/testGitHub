package com.liiwin.initlistener;

/**
 * <p>标题： 初始化所有的WebService</p>
 * <p>功能： </p>
 * <p>所属模块： rootbase</p>
 * <p>版权： Copyright © 2017 zyzhu</p>
 * <p>公司: xyz.zyzhu</p>
 * <p>创建日期：2017年8月11日 上午9:52:49</p>
 * <p>类全名：com.liiwin.initlistener.LoadWebServiceListener</p>
 * 作者：赵玉柱
 * 初审：
 * 复审：
 * 监听使用界面:
 * @version 8.0
 */
public interface LoadWebServiceListener
{
	void loadWebService();
}
