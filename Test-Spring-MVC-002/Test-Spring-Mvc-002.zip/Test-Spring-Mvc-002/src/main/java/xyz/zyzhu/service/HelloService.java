package xyz.zyzhu.service;

import xyz.zyzhu.entry.Hello;
/**
 * <p>标题： TODO</p>
 * <p>功能： </p>
 * <p>所属模块： TODO</p>
 * <p>版权： Copyright © 2017 zyzhu</p>
 * <p>公司: zyzhu.xyz</p>
 * <p>创建日期：2017年8月1日 下午3:33:54</p>
 * <p>类全名：xyz.zyzhu.service.impl.HelloService</p>
 * 作者：赵玉柱
 * 初审：
 * 复审：
 * 监听使用界面:
 * @version 8.0
 */
public interface HelloService
{
	public void say(Hello hello);
}
