package xyz.zyzhu.dao;

import xyz.zyzhu.entry.Hello;
/**
 * <p>标题： 测试dao</p>
 * <p>功能： </p>
 * <p>所属模块： 测试</p>
 * <p>版权： Copyright © 2017 zyzhu</p>
 * <p>公司: zyzhu.xyz</p>
 * <p>创建日期：2017年8月1日 下午3:32:43</p>
 * <p>类全名：xyz.zyzhu.dao.HelloDao</p>
 * 作者：赵玉柱
 * 初审：
 * 复审：
 * 监听使用界面:
 * @version 8.0
 */
public interface HelloDao
{
	public void say(Hello hello);
}
